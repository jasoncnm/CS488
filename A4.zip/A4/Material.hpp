// Termm--Fall 2020

#pragma once

class Material {
public:
  virtual ~Material();

protected:
  Material();
};
